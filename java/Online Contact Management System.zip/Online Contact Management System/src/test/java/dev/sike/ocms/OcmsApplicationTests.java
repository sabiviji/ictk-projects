package dev.sike.ocms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OcmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
